## Swiss Army Man

The swiss army knife utility for Python
