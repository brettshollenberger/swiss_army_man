## Swiss Army Man

The swiss army knife utility for Python

```
poetry build
poetry run twine upload dist/*
```
