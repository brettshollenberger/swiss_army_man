import numpy as np

def normalize(data):
    return data / np.max(data)